let products = JSON.parse(localStorage.getItem("products")) || [];

// Seller submits product
function submitProduct() {
  let name = document.getElementById("productName").value;
  let desc = document.getElementById("productDesc").value;
  let loc = document.getElementById("productLocation").value;
  let fileInput = document.getElementById("productImage");

  let reader = new FileReader();
  reader.onload = function(e) {
    let product = {
      name: name,
      desc: desc,
      location: loc,
      image: e.target.result,
      status: "Pending Approval",
      price: null,
      certified: false,
      warranty: null,
      video: null
    };
    products.push(product);
    localStorage.setItem("products", JSON.stringify(products));
    document.getElementById("statusMessage").innerText = "Submitted for Admin Approval!";
  };
  if (fileInput.files[0]) {
    reader.readAsDataURL(fileInput.files[0]);
  }
}

// Load products in Admin Dashboard
function loadAdminProducts() {
  let table = document.getElementById("adminTable");
  table.innerHTML = "";
  products.forEach((p, index) => {
    table.innerHTML += `
      <tr>
        <td><img src="${p.image}" style="max-width:80px"><br>${p.name}</td>
        <td>${p.desc}<br><b>Location:</b> ${p.location}</td>
        <td>${p.status}</td>
        <td>
          ${p.status === "Pending Approval" ? `
            <input type="number" id="price${index}" placeholder="Set Price"><br>
            <input type="text" id="video${index}" placeholder="Video URL"><br>
            <label><input type="checkbox" id="cert${index}"> Certified</label><br>
            <label><input type="checkbox" id="warr${index}"> 1-Month Warranty</label><br>
            <button onclick="publishProduct(${index})">Publish</button>
          ` : "Published"}
        </td>
      </tr>
    `;
  });
}

// Admin publishes product
function publishProduct(index) {
  let p = products[index];
  p.price = document.getElementById(`price${index}`).value;
  p.video = document.getElementById(`video${index}`).value;
  p.certified = document.getElementById(`cert${index}`).checked;
  p.warranty = document.getElementById(`warr${index}`).checked ? "1 Month" : "No Warranty";
  p.status = "Refurbished";

  products[index] = p;
  localStorage.setItem("products", JSON.stringify(products));
  alert("Product Published to Store!");
  loadAdminProducts();
}

// Load products in Buyer Store
function loadStoreProducts() {
  let grid = document.getElementById("storeGrid");
  grid.innerHTML = "";
  products.filter(p => p.status === "Refurbished").forEach(p => {
    grid.innerHTML += `
      <div class="product-card">
        <img src="${p.image}" style="max-width:150px">
        <h3>${p.name}</h3>
        <p>${p.desc}</p>
        <p><b>Price:</b> ₹${p.price}</p>
        <p><span class="certified">${p.certified ? "✔ Certified" : ""}</span></p>
        <p>Warranty: ${p.warranty}</p>
        <a href="${p.video}" target="_blank">Watch Demo</a><br>
        <button>Order Now</button>
      </div>
    `;
  });
}
